<?php

namespace App\Models\Notice;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SurveyAnswers extends Model
{
    use HasFactory;

    protected $fillable = ['question_id', 'user_id', 'option_id'];

    public function question()
    {
        return $this->belongsTo(SurveyQuestions::class, 'question_id');
    }
}
